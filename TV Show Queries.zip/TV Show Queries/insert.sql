-- NAME : FARZANEH GHASEMI JAVID
-- STUDENT NUMBER: 1741770

-- insering the values for coach table
-- (coach id, name, surname, dob, phone, salary)
insert into COACH values
  (2010121993, 'Zayn', 'Malik', '1993-01-12', 0744239756, 120000),
  (2009141984, 'Olly', 'Murs', '1984-05-14', 0745874520, 90000),
  (2004171991,'Ed', 'Sheeran', '1991-02-17', 0744824639, 100000);

-- inserting the values for contender table
-- (contender id, stage name, type, coach id)
insert into CONTENDER values
  (2018211995, 'Stage 1', 'G', 2010121993),
  (2018071996, 'Satge 2', 'S', 2009141984),
  (2018131993, 'Satge 3', 'S', 2010121993),
  (2018251996, 'Satge 4', 'S', 2009141984),
  (2018111993, 'Satge 5', 'S', 2010121993);

-- inserting the values for participant table 
-- ( participant id, name, surname, dob, phone, salary, gender, contender id)
insert into PARTICIPANT values
  (201801, 'Margaret', 'Adams', '1995-04-21', 0746953728,120,'F',2018211995), 
  (201802, 'Samirah', 'Rahim', '1995-06-18', 0734927845, 100, 'F', 2018211995), 
  (201803, 'George', 'Douglas', '1994-10-11', 0735198259, 180, 'M', 2018211995),  
  (201804, 'Dominic', 'Arron', '1996-02-07', 0748269936, 210, 'M', 2018071996), 
  (201805, 'Sophie', 'Alice', '1993-12-01', 0737981766, 145, 'F', 2018111993), 
  (201806, 'Christopher', 'Ian', '1994-05-16', 0748275533, 185, 'M', 2018211995),  
  (201807, 'Victoria', 'Jane', '1993-04-13', 0734879956, 135, 'F', 2018131993), 
  (201808, 'Mia', 'Sophie', '1996-09-19', 0744882634, 115, 'F', 2018211995), 
  (201809, 'Abdul', 'Rahman', '1993-07-11', 0745289898, 160, 'M', 2018211995),   
  (201810, 'Samah', 'Almas', '1996-03-25', 0743874466, 150, 'F', 2018251996); 

-- inserting the values for tv show table
-- (show id, show date, start time, end time, location)
insert into TVSHOW values
  (936527155,'2018-03-10' , '17:00:00', '19:00:00', 'Taims'), 
  (139767418,'2018-03-11' , '19:00:00', '21:00:00', 'Edgware'), 
  (166728238,'2018-04-07' , '21:00:00', '23:00:00', 'Waterloo'), 
  (665380924,'2018-04-08' , '15:00:00', '17:00:00', 'Oxford Street'); 

-- inserting the values for coach in show table
-- (coach id, show id)
insert into COACHINSHOW values
  (2010121993, 936527155), 
  (2004171991, 139767418), 
  (2004171991, 936527155), 
  (2010121993, 166728238), 
  (2004171991, 665380924); 

-- inserting the values for contender in show
-- (contender id, show id)
insert into CONTENDERINSHOW values
  (2018071996, 166728238),
  (2018111993, 665380924),
  (2018211995, 936527155),
  (2018251996, 139767418),
  (2018131993, 936527155);